// Fictional demo script. Reads the catalog JSON relative to the page.
(function(){var ul=document.getElementById("catalog");if(!ul)return;fetch("../data/catalog.json").then(function(r){return r.json()}).then(function(d){d.items.forEach(function(i){var li=document.createElement("li");li.textContent=i.title+" — "+i.shelf;ul.appendChild(li);});});})();
